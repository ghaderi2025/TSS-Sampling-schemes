#####################################################
#Using RSS in two successive sampling #
# A_2 exists only for m=9, for other m, we need the first sample size equal to the square of the matched sample size#
#we wrote both schemes A_1 and A_2 only for m=3,5, 9#
library(sn)                # generate trivariate normal
library(MLmetrics) # calculate MSE
N=1000
U<-1:N
l=5000
n=100
m=9
#####################################################
#ybarc3q1; ybar_c3 base on RSS with scheme A_1 #
#ybarc3q2; ybar_c3 base on RSS with scheme A_2 #
#ybarc3srs; ybar_c3 base under scheme SRS#
ybarc3q1<-ybarc1srs<-ybarc1q2<-rep(0,times=l)
#####################################################
# selection rho #
rho<-0.2
#####################################################
# create bivariate normal distribution in XY#
# x is study variable in the first occasion; y is study variable in the second occasion#
# phi is alpha optimum under scheme SRS #
# x1 is sample in the first occasion#
# xx2 is matched portion of the first sample under scheme SRS; yy2 is matched portion of the second sample under scheme SRS #
# y3 is fresh sample in the current occasion#
# rx2 is matched portion of the first sample under scheme A_1; g2 is matched portion of the second sample under scheme A_1 #
# rx2prim is matched portion of the first sample under scheme A_2; v2 is matched portion of the second sample under scheme A_2 #
#####################################################

fq1<-function(alphaa){
for (i in 1:l){
sdd1<-64
sdd2<-100
sd1<-sqrt(sdd1)
sd2<-sqrt(sdd2)
sd<-rho*sqrt(sdd1*sdd2)
sigma <- matrix(c(sdd1,sd ,sd, sdd2), 2, 2)
cp <- list(mean=c(100,120), var.cov=sigma, gamma1=c(0,0))
dp <- cp2dp(cp, "SN")
XY<- rmsn(N, dp=dp)
x<-XY[,1]
y<-XY[,2]

e1<-(n-m)/n
rhop<-cor(x,y)
phi1<-e1-((e1*rhop)^2)
phi2<-1-((e1*rhop)^2)
phi<-phi1/phi2

s<-sample(U,size=n)
x1<-x[s]
xbarn<-mean(x1)
s12<-sample(s,size=m)
xx2<-x[s12]
yy2<-y[s12]
xbarmnew1<-mean(xx2)
ybarmnew1<-mean(yy2)
bhatnew3<-cov(yy2,xx2)/var(xx2)
s2<-sample(U[-s],siz=n-m)
y3<-y[s2]
ybarn<- mean(y3)
ybarc3srs[i]<-alphaa*ybarn+(1-alphaa)*((ybarmnew1+(bhatnew3*(xbarn-xbarmnew1))))

rx<-c()
for(p in 1:m){
r<-sample(s,size=m,replace = T)
rx[p]<-sort(x[r])[p]
}

rx2<-rx[1:m]
rxbarm<-mean(rx2)

g2<-c()
for(j in 1:m){
g2[j]<-y[s[x1==rx2[j]]]
}

gbarm<-mean(g2)
bhatr1<-cov(rx2,g2)/var(rx2)

ybarc3q1[i]<-alphaa*ybarn+(1-alphaa)*((gbarm+(bhatr1*(xbarn-rxbarm))))

r1prim<-s12;rxx1<-sort(x[r1prim])
r2prim<-sample(setdiff(s1,r1prim),size=m,replace = F);rxx2<-sort(x[r2prim])
r3prim<-sample(setdiff(s1,c(r1prim,r2prim)),size=m,replace = F);rxx3<-sort(x[r3prim])
r4prim<-sample(setdiff(s1,c(r1prim,r2prim,r3prim)),size=m,replace = F);rxx4<-sort(x[r4prim])
r5prim<-sample(setdiff(s1,c(r1prim,r2prim,r3prim,r4prim)),size=m,replace = F);rxx5<-sort(x[r5prim])
r6primcut<-c(r1prim,r2prim,r3prim,r4prim,r5prim)
r6prim<-sample(setdiff(s1,r6primcut),size=m,replace = F);rxx6<-sort(x[r6prim])
r7primcut<-c(r1prim,r2prim,r3prim,r4prim,r5prim,r6prim)
r7prim<-sample(setdiff(s1,r7primcut),size=m,replace = F);rxx7<-sort(x[r7prim])
r8primcut<-c(r1prim,r2prim,r3prim,r4prim,r5prim,r6prim,r7prim)
r8prim<-sample(setdiff(s1,r8primcut),size=m,replace = F);rxx8<-sort(x[r8prim])
r9primcut<-c(r1prim,r2prim,r3prim,r4prim,r5prim,r6prim,r7prim,r8prim)
r9prim<-sample(setdiff(s1,r9primcut),size=m,replace = F);rxx9<-sort(x[r9prim])
rx2prim<-c(rxx1[1],rxx2[2],rxx3[3],rxx4[4],rxx5[5],rxx6[6],rxx7[7],rxx8[8],rxx9[9])
rprimxbarm<-mean(rx2prim)

v2<-c()
for(j in 1:m){
v2[j]<-y[s[x1==rx2prim[j]]]
}

vbarm=mean(v2)
bhatrprim1<-cov(rx2prim,v2)/var(rx2prim)

ybarc3q2[i]<-alphaa*ybarn+(1-alphaa)*((vbarm+(bhatrprim1*(xbarn-rprimxbarm))))
}
newlist<-list(y,ybarc3srs,ybarc3q1,ybarc3q2,phi)
return(newlist)

}
#####################################################
# e3q1; The relative efficiency of two estimators ybarc3srs and ybarc3q1 #
# e4q1; The relative efficiency of two estimators ybarc3srs and ybarc3q2 #
# Finding simulated alpha value with minimum variance under schemes A_1 and A_2#
# g3q1; variance(ybarc3q1) #
# g4q1; variance(ybarc3q2) #
#####################################################

meany1<-mean(fq1(1)[[1]]) #y

aa<-seq(0,1,by=0.1);length(aa)

e3q1<-e4q1<-c(0,times=length(aa))
g3q1<-g4q1<-c(0,times=length(aa))

for(k in 1:length(aa)){
e3q1[k]<-MSE(fq1(aa[k])[[2]],meany1)/MSE(fq1(aa[k])[[3]],meany1)
e4q1[k]<-MSE(fq1(aa[k])[[2]],meany1)/MSE(fq1(aa[k])[[4]],meany1)
g3q1[k]<-var(fq1(aa[k])[[3]])
g4q1[k]<-var(fq1(aa[k])[[4]])
}
#Finding a more accurate value for the simulated  optimal alpha #
# alpha3q1 is simulated  optimal alpha under scheme A_1   #
# alpha4q1 is simulated  optimal alpha under scheme A_2#

opt3<-aa[which(g3q1==min(g3q1))]
opt4<-aa[which(g4q1==min(g4q1))]

t3<- seq(opt3-0.1, opt3+0.1,by=0.01)
t4<- seq(opt4-0.1, opt4+0.1,by=0.01)

v3<-v4<-c(0,times=length(t1))

for(k in 1:length(t3)){
v3[k]<-var(fq1(t3[k])[[3]])
}
alpha3q1<-t3[which(v3==min(v3))]

for(k in 1:length(t4)){
v4[k]<-var(fq1(t4[k])[[4]])
}
alpha4q1<-t4[which(v4==min(v4))]
# Relative bias percentage #
# bias3q1; RBP ybarc3q1 #
# bias4q1; RBP ybarc3q2 #

bias3q1<-mean( fq1(alpha3q1)[[3]])-meany1
bias4q1<-mean( fq1(alpha4q1)[[4]])-meany1

##################################
rho<-0.5

fq2<-function(alphaa){
for (i in 1:l){
sdd1<-64
sdd2<-100
sd1<-sqrt(sdd1)
sd2<-sqrt(sdd2)
sd<-rho*sqrt(sdd1*sdd2)
sigma <- matrix(c(sdd1,sd ,sd, sdd2), 2, 2)
cp <- list(mean=c(100,120), var.cov=sigma, gamma1=c(0,0))
dp <- cp2dp(cp, "SN")
XY<- rmsn(N, dp=dp)
x<-XY[,1]
y<-XY[,2]

e1<-(n-m)/n
rhop<-cor(x,y)
phi1<-e1-((e1*rhop)^2)
phi2<-1-((e1*rhop)^2)
phi<-phi1/phi2

s<-sample(U,size=n)
x1<-x[s]
xbarn<-mean(x1)
s12<-sample(s,size=m)
xx2<-x[s12]
yy2<-y[s12]
xbarmnew1<-mean(xx2)
ybarmnew1<-mean(yy2)
bhatnew3<-cov(yy2,xx2)/var(xx2)
s2<-sample(U[-s],siz=n-m)
y3<-y[s2]
ybarn<- mean(y3)
ybarc3srs[i]<-alphaa*ybarn+(1-alphaa)*((ybarmnew1+(bhatnew3*(xbarn-xbarmnew1))))

rx<-c()
for(p in 1:m){
r<-sample(s,size=m,replace = T)
rx[p]<-sort(x[r])[p]
}

rx2<-rx[1:m]
rxbarm<-mean(rx2)
g2<-c()
for(j in 1:m){
g2[j]<-y[s[x1==rx2[j]]]
}

gbarm<-mean(g2)
bhatr1<-cov(rx2,g2)/var(rx2)
ybarc3q1[i]<-alphaa*ybarn+(1-alphaa)*((gbarm+(bhatr1*(xbarn-rxbarm))))

r1prim<-s12;rxx1<-sort(x[r1prim])
r2prim<-sample(setdiff(s1,r1prim),size=m,replace = F);rxx2<-sort(x[r2prim])
r3prim<-sample(setdiff(s1,c(r1prim,r2prim)),size=m,replace = F);rxx3<-sort(x[r3prim])
r4prim<-sample(setdiff(s1,c(r1prim,r2prim,r3prim)),size=m,replace = F);rxx4<-sort(x[r4prim])
r5prim<-sample(setdiff(s1,c(r1prim,r2prim,r3prim,r4prim)),size=m,replace = F);rxx5<-sort(x[r5prim])
r6primcut<-c(r1prim,r2prim,r3prim,r4prim,r5prim)
r6prim<-sample(setdiff(s1,r6primcut),size=m,replace = F);rxx6<-sort(x[r6prim])
r7primcut<-c(r1prim,r2prim,r3prim,r4prim,r5prim,r6prim)
r7prim<-sample(setdiff(s1,r7primcut),size=m,replace = F);rxx7<-sort(x[r7prim])
r8primcut<-c(r1prim,r2prim,r3prim,r4prim,r5prim,r6prim,r7prim)
r8prim<-sample(setdiff(s1,r8primcut),size=m,replace = F);rxx8<-sort(x[r8prim])
r9primcut<-c(r1prim,r2prim,r3prim,r4prim,r5prim,r6prim,r7prim,r8prim)
r9prim<-sample(setdiff(s1,r9primcut),size=m,replace = F);rxx9<-sort(x[r9prim])
rx2prim<-c(rxx1[1],rxx2[2],rxx3[3],rxx4[4],rxx5[5],rxx6[6],rxx7[7],rxx8[8],rxx9[9])
rprimxbarm<-mean(rx2prim)

v2<-c()
for(j in 1:m){
v2[j]<-y[s[x1==rx2prim[j]]]
}

vbarm=mean(v2)
bhatrprim1<-cov(rx2prim,v2)/var(rx2prim)

ybarc3q2[i]<-alphaa*ybarn+(1-alphaa)*((vbarm+(bhatrprim1*(xbarn-rprimxbarm))))
}
newlist<-list(y,ybarc3srs,ybarc3q1,ybarc3q2,phi)
return(newlist)

}

meany2<-mean(fq2(1)[[1]]) #y

e3q2<-e4q2<-c(0,times=length(aa))
g3q2<-g4q2<-c(0,times=length(aa))

for(k in 1:length(aa)){
e3q2[k]<-MSE(fq2(aa[k])[[2]],meany1)/MSE(fq2(aa[k])[[3]],meany2)
e4q2[k]<-MSE(fq2(aa[k])[[2]],meany1)/MSE(fq2(aa[k])[[4]],meany2)
g3q2[k]<-var(fq2(aa[k])[[3]])
g4q2[k]<-var(fq2(aa[k])[[4]])
}
opt3<-aa[which(g3q2==min(g3q2))]
opt4<-aa[which(g4q2==min(g4q2))]

t3<- seq(opt3-0.1, opt3+0.1,by=0.01)
t4<- seq(opt4-0.1, opt4+0.1,by=0.01)

v3<-v4<-c(0,times=length(t1))

for(k in 1:length(t3)){
v3[k]<-var(fq2(t3[k])[[3]])
}
alpha3q2<-t3[which(v3==min(v3))]

for(k in 1:length(t4)){
v4[k]<-var(fq2(t4[k])[[4]])
}
alpha4q2<-t4[which(v4==min(v4))]

bias3q2<-mean( fq2(alpha3q2)[[3]])-meany2
bias4q2<-mean( fq2(alpha4q2)[[4]])-meany2

#############################
rho<-0.8

fq3<-function(alphaa){
for (i in 1:l){
sdd1<-64
sdd2<-100
sd1<-sqrt(sdd1)
sd2<-sqrt(sdd2)
sd<-rho*sqrt(sdd1*sdd2)
sigma <- matrix(c(sdd1,sd ,sd, sdd2), 2, 2)
cp <- list(mean=c(100,120), var.cov=sigma, gamma1=c(0,0))
dp <- cp2dp(cp, "SN")
XY<- rmsn(N, dp=dp)
x<-XY[,1]
y<-XY[,2]

e1<-(n-m)/n
rhop<-cor(x,y)
phi1<-e1-((e1*rhop)^2)
phi2<-1-((e1*rhop)^2)
phi<-phi1/phi2

s<-sample(U,size=n)
x1<-x[s]
xbarn<-mean(x1)
s12<-sample(s,size=m)
xx2<-x[s12]
yy2<-y[s12]
xbarmnew1<-mean(xx2)
ybarmnew1<-mean(yy2)
bhatnew3<-cov(yy2,xx2)/var(xx2)
s2<-sample(U[-s],siz=n-m)
y3<-y[s2]
ybarn<- mean(y3)
ybarc3srs[i]<-alphaa*ybarn+(1-alphaa)*((ybarmnew1+(bhatnew3*(xbarn-xbarmnew1))))

rx<-c()
for(p in 1:m){
r<-sample(s,size=m,replace = T)
rx[p]<-sort(x[r])[p]
}

rx2<-rx[1:m]

rxbarm<-mean(rx2)
g2<-c()
for(j in 1:m){
g2[j]<-y[s[x1==rx2[j]]]
}

gbarm<-mean(g2)
bhatr1<-cov(rx2,g2)/var(rx2)
ybarc3q1[i]<-alphaa*ybarn+(1-alphaa)*((gbarm+(bhatr1*(xbarn-rxbarm))))

r1prim<-s12;rxx1<-sort(x[r1prim])
r2prim<-sample(setdiff(s1,r1prim),size=m,replace = F);rxx2<-sort(x[r2prim])
r3prim<-sample(setdiff(s1,c(r1prim,r2prim)),size=m,replace = F);rxx3<-sort(x[r3prim])
r4prim<-sample(setdiff(s1,c(r1prim,r2prim,r3prim)),size=m,replace = F);rxx4<-sort(x[r4prim])
r5prim<-sample(setdiff(s1,c(r1prim,r2prim,r3prim,r4prim)),size=m,replace = F);rxx5<-sort(x[r5prim])
r6primcut<-c(r1prim,r2prim,r3prim,r4prim,r5prim)
r6prim<-sample(setdiff(s1,r6primcut),size=m,replace = F);rxx6<-sort(x[r6prim])
r7primcut<-c(r1prim,r2prim,r3prim,r4prim,r5prim,r6prim)
r7prim<-sample(setdiff(s1,r7primcut),size=m,replace = F);rxx7<-sort(x[r7prim])
r8primcut<-c(r1prim,r2prim,r3prim,r4prim,r5prim,r6prim,r7prim)
r8prim<-sample(setdiff(s1,r8primcut),size=m,replace = F);rxx8<-sort(x[r8prim])
r9primcut<-c(r1prim,r2prim,r3prim,r4prim,r5prim,r6prim,r7prim,r8prim)
r9prim<-sample(setdiff(s1,r9primcut),size=m,replace = F);rxx9<-sort(x[r9prim])
rx2prim<-c(rxx1[1],rxx2[2],rxx3[3],rxx4[4],rxx5[5],rxx6[6],rxx7[7],rxx8[8],rxx9[9])
rprimxbarm<-mean(rx2prim)

v2<-c()
for(j in 1:m){
v2[j]<-y[s[x1==rx2prim[j]]]
}

vbarm=mean(v2)
bhatrprim1<-cov(rx2prim,v2)/var(rx2prim)

ybarc3q2[i]<-alphaa*ybarn+(1-alphaa)*((vbarm+(bhatrprim1*(xbarn-rprimxbarm))))
}
newlist<-list(y,ybarc3srs,ybarc3q1,ybarc3q2,phi)
return(newlist)

}

meany3<-mean(fq3(1)[[1]]) #y

e3q3<-e4q3<-c(0,times=length(aa))
g3q3<-g4q3<-c(0,times=length(aa))

for(k in 1:length(aa)){
e3q3[k]<-MSE(fq3(aa[k])[[2]],meany3)/MSE(fq3(aa[k])[[3]],meany3)
e4q3[k]<-MSE(fq3(aa[k])[[2]],meany3)/MSE(fq3(aa[k])[[4]],meany3)
g3q3[k]<-var(fq3(aa[k])[[3]])
g4q3[k]<-var(fq3(aa[k])[[4]])
}

opt3<-aa[which(g3q3==min(g3q3))]
opt4<-aa[which(g4q3==min(g4q3))]

t3<- seq(opt3-0.1, opt3+0.1,by=0.01)
t4<- seq(opt4-0.1, opt4+0.1,by=0.01)

v3<-v4<-c(0,times=length(t1))

for(k in 1:length(t3)){
v3[k]<-var(fq3(t3[k])[[3]])
}
alpha3q3<-t3[which(v3==min(v3))]

for(k in 1:length(t4)){
v4[k]<-var(fq3(t4[k])[[4]])
}
alpha4q3<-t4[which(v4==min(v4))]

bias3q3<-mean( fq3(alpha3q3)[[3]])-meany3
bias4q3<-mean( fq3(alpha4q3)[[4]])-meany3

