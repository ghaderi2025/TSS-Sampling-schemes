#without an auxiliary variable, schemes A_3 and A_4#
library(sn)               # generate trivariate normal
library(MLmetrics)        # calculate MSE
N=1000
U<-1:N
l=5000
n=100
m=15
#######################################################################
#ybar_c1q3;  ybar_c1 base on quantile with scheme A_3 #
#ybar_c1q4;  ybar _1 base on quantile with scheme A_4 #
#ybar_c1srs; ybar_c1 base under scheme SRS               #
ybar_c1q3<-ybar_c1srs<-ybar_c1q4<-rep(0,times=l)
#######################################################################
# dm1 is  place for selecting quantile in the matched portion A_3 #
# dm2 is  place for selecting quantile in the matched portion A_4 #
h<-c()
for(l in 1:m){
h[l]<-l*n/(m+1)
}
dm1<-round(h)
f<-c()
for(l in 1:(m-2)){
f[l]<-l*n/(m-1)
}
dm2<-c(1,round(f),n)

#######################################################################
# create bivariate normal distribution in XY#
#x is study variable in the first occasion; y is study variable in the second occasion#
#phi is alpha optimum under scheme SRS; x1 is sample in the first occasion#
# x2 is matched portion of the first sample under scheme A_3; y2 is matched portion of the second sample under scheme A_3 #
#y3 is fresh sample in the current occasion#
# xnew2 is matched portion of the first sample under scheme A_4; y2 is matched portion of the second sample under scheme A_4 #
# xx2 is matched portion of the first sample under scheme SRS; yy2 is matched portion of the second sample under scheme SRS #
#######################################################################
# selection rho #
rho<-0.2
fq1<-function(alphaa){
for (i in 1:l){
sdd1<-64
sdd2<-100
sd1<-sqrt(sdd1)
sd2<-sqrt(sdd2)
sd<-rho*sqrt(sdd1*sdd2)
sigma <- matrix(c(sdd1,sd ,sd, sdd2), 2, 2)
cp <- list(mean=c(100,120), var.cov=sigma, gamma1=c(0,0))
dp <- cp2dp(cp, "SN")
XY<- rmsn(N, dp=dp)
x<-XY[,1]
y<-XY[,2]
e1<-(n-m)/n
rhop<-cor(x,y)
phi1<-e1-((e1*rhop)^2)
phi2<-1-((e1*rhop)^2)
phi<-phi1/phi2
s<-sample(U,size=n)
x1<-x[s]
xbarn<-mean(x1)

ss<-sort(x1)
x2<-ss[dm1]
y2<-c()
for(j in 1:m){
y2[j]<-y[s[x1==x2[j]]]
}
xbarm<-mean(x2)
ybarm<-mean(y2)
bhatnew1<-cov(x2,y2)/var(x2)
s2<-sample(U[-s],siz=n-m)
y3<-y[s2]
ybarn<- mean(y3)
ybar_c1q3[i]<-alphaa*ybarn+(1-alphaa)*((ybarm+(bhatnew1*(xbarn-xbarm))))

xnew2<-ss[dm2]
ynew2<-c()
for(j in 1:m){
ynew2[j]<-y[s[x1==xnew2[j]]]
}
xbarmnew<-mean(xnew2)
ybarmnew<-mean(ynew2)
bhatnew2<-cov(xnew2,ynew2)/var(xnew2)
ybar_c1q4[i]<-alphaa*ybarn+(1-alphaa)*((ybarmnew+(bhatnew2*(xbarn-xbarmnew))))

s12<-sample(s,size=m)
xx2<-x[s12]
yy2<-y[s12]
xbarmnew1<-mean(xx2)
ybarmnew1<-mean(yy2)
bhatnew3<-cov(yy2,xx2)/var(xx2)
ybar_c1srs[i]<-alphaa*ybarn+(1-alphaa)*((ybarmnew1+(bhatnew3*(xbarn-xbarmnew1))))
}
newlist<-list(ybar_c1q3,ybar_c1srs,y,ybar_c1q4,phi)
return(newlist)
} 

#######################################################################
# e1q1; The relative efficiency of two estimators ybarc1srs and ybar_c1q3 #
# e2q1; The relative efficiency of two estimators ybarc1srs and ybar_c1q4 #
# Finding simulated alpha value with minimum variance under schemes A_3 and A_4#
# g1q1; variance(ybar_c1q3) #
# g2q1; variance(ybar_c1q4) #
#######################################################################
meany1<-mean(fq1(1)[[3]])     # mean(y) is not function of alpha#

aa<-seq(0,1,by=0.1)
e1q1<-e2q1<-c(0,times=length(aa))
g1q1<-g2q1<-c(0,times=length(aa))
for(k in 1:length(aa)){
e1q1[k]<-MSE(fq1(aa[k])[[2]],meany1)/MSE(fq1(aa[k])[[1]],meany1)
e2q1[k]<-MSE(fq1(aa[k])[[2]],meany1)/MSE(fq1(aa[k])[[4]],meany1)
g1q1[k]<-var(fq1(aa[k])[[1]])
g2q1[k]<-var(fq1(aa[k])[[4]])
}
#######################################################################
#Finding a more accurate value for the simulated  optimal alpha #
# alpha1q1 is simulated  optimal alpha under scheme A_3; alpha2q1 is simulated  optimal alpha under scheme A_4 #

opt1<-aa[which(g1q1==min(g1q1))]
opt2<-aa[which(g2q1==min(g2q1))]
t1<- seq(opt1-0.1, opt1+0.1,by=0.01)
t2<- seq(opt2-0.1, opt2+0.1,by=0.01)
v1<-v2<-c(0,times=length(t1))
for(k in 1:length(t1)){
v1[k]<-var(fq1(t1[k])[[1]])
}
alpha1q1<-t1[which(v1==min(v1))]

for(k in 1:length(t1)){
v2[k]<-var(fq1(t2[k])[[4]])
}
alpha2q1<-t2[which(v2==min(v2))]
#######################################################################
# Relative bias percentage #
# bias1q1; RBP ybar_c1q3 #
# bias2q1; RBP ybar_c1q4 #

bias1q1<-mean( fq1(alpha1q1)[[1]])-meany1
bias2q1<-mean( fq1(alpha2q1)[[4]])-meany1

#######################################################################
rho<-0.5

fq2<-function(alphaa){
for (i in 1:l){
sdd1<-64
sdd2<-100
sd1<-sqrt(sdd1)
sd2<-sqrt(sdd2)
sd<-rho*sqrt(sdd1*sdd2)
sigma <- matrix(c(sdd1,sd ,sd, sdd2), 2, 2)
cp <- list(mean=c(100,120), var.cov=sigma, gamma1=c(0,0))
dp <- cp2dp(cp, "SN")
XY<- rmsn(N, dp=dp)
x<-XY[,1]
y<-XY[,2]
e1<-(n-m)/n
rhop<-cor(x,y)
phi1<-e1-((e1*rhop)^2)
phi2<-1-((e1*rhop)^2)
phi<-phi1/phi2
s<-sample(U,size=n)
x1<-x[s]
xbarn<-mean(x1)
ss<-sort(x1)
x2<-ss[dm1]
y2<-c()
for(j in 1:m){
y2[j]<-y[s[x1==x2[j]]]
}
xbarm<-mean(x2)
ybarm<-mean(y2)
bhatnew1<-cov(x2,y2)/var(x2)
s2<-sample(U[-s],siz=n-m)
y3<-y[s2]
ybarn<- mean(y3)
ybar_c1q3[i]<-alphaa*ybarn+(1-alphaa)*((ybarm+(bhatnew1*(xbarn-xbarm))))

xnew2<-ss[dm2]
ynew2<-c()
for(j in 1:m){
ynew2[j]<-y[s[x1==xnew2[j]]]
}
xbarmnew<-mean(xnew2)
ybarmnew<-mean(ynew2)
bhatnew2<-cov(xnew2,ynew2)/var(xnew2)
ybar_c1q4[i]<-alphaa*ybarn+(1-alphaa)*((ybarmnew+(bhatnew2*(xbarn-xbarmnew))))

s12<-sample(s,size=m)
xx2<-x[s12]
yy2<-y[s12]
xbarmnew1<-mean(xx2)
ybarmnew1<-mean(yy2)
bhatnew3<-cov(yy2,xx2)/var(xx2)
ybar_c1srs[i]<-alphaa*ybarn+(1-alphaa)*((ybarmnew1+(bhatnew3*(xbarn-xbarmnew1))))
}
newlist<-list(ybar_c1q3,ybar_c1srs,y,ybar_c1q4,phi)
return(newlist)
} 
meany2<-mean(fq2(1)[[3]])

aa<-seq(0,1,by=0.1)
e1q2<-e2q2<-c(0,times=length(aa))
g1q2<-g2q2<-c(0,times=length(aa))
for(k in 1:length(aa)){
e1q2[k]<-MSE(fq2(aa[k])[[2]],meany2)/MSE(fq2(aa[k])[[1]],meany2)
e2q2[k]<-MSE(fq2(aa[k])[[2]],meany2)/MSE(fq2(aa[k])[[4]],meany2)
g1q2[k]<-var(fq2(aa[k])[[1]])
g2q2[k]<-var(fq2(aa[k])[[4]])
}

opt1<-aa[which(g1q2==min(g1q2))]
opt2<-aa[which(g2q2==min(g2q2))]

t1<- seq(opt1-0.1, opt1+0.1,by=0.01)
t2<- seq(opt2-0.1, opt2+0.1,by=0.01)

v1<-v2<-c(0,times=length(t1))
for(k in 1:length(t1)){
v1[k]<-var(fq2(t1[k])[[1]])
}
alpha1q2<-t1[which(v1==min(v1))]

for(k in 1:length(t1)){
v2[k]<-var(fq2(t2[k])[[4]])
}
alpha2q2<-t2[which(v2==min(v2))]

bias1q2<-mean( fq2(alpha1q2)[[1]])-meany2
bias2q2<-mean( fq2(alpha2q2)[[4]])-meany2

#######################################################################
rho<-0.8

fq3<-function(alphaa){
for (i in 1:l){
sdd1<-64
sdd2<-100
sd1<-sqrt(sdd1)
sd2<-sqrt(sdd2)
sd<-rho*sqrt(sdd1*sdd2)
sigma <- matrix(c(sdd1,sd ,sd, sdd2), 2, 2)
cp <- list(mean=c(100,120), var.cov=sigma, gamma1=c(0,0))
dp <- cp2dp(cp, "SN")
XY<- rmsn(N, dp=dp)
x<-XY[,1]
y<-XY[,2]
e1<-(n-m)/n
rhop<-cor(x,y)
phi1<-e1-((e1*rhop)^2)
phi2<-1-((e1*rhop)^2)
phi<-phi1/phi2
s<-sample(U,size=n)
x1<-x[s]
xbarn<-mean(x1)
ss<-sort(x1)
x2<-ss[dm1]
y2<-c()
for(j in 1:m){
y2[j]<-y[s[x1==x2[j]]]
}
xbarm<-mean(x2)
ybarm<-mean(y2)
bhatnew1<-cov(x2,y2)/var(x2)
s2<-sample(U[-s],siz=n-m)
y3<-y[s2]
ybarn<- mean(y3)
ybar_c1q3[i]<-alphaa*ybarn+(1-alphaa)*((ybarm+(bhatnew1*(xbarn-xbarm))))

xnew2<-ss[dm2]
ynew2<-c()
for(j in 1:m){
ynew2[j]<-y[s[x1==xnew2[j]]]
}
xbarmnew<-mean(xnew2)
ybarmnew<-mean(ynew2)
bhatnew2<-cov(xnew2,ynew2)/var(xnew2)
ybar_c1q4[i]<-alphaa*ybarn+(1-alphaa)*((ybarmnew+(bhatnew2*(xbarn-xbarmnew))))

s12<-sample(s,size=m)
xx2<-x[s12]
yy2<-y[s12]
xbarmnew1<-mean(xx2)
ybarmnew1<-mean(yy2)
bhatnew3<-cov(yy2,xx2)/var(xx2)
ybar_c1srs[i]<-alphaa*ybarn+(1-alphaa)*((ybarmnew1+(bhatnew3*(xbarn-xbarmnew1))))
}
newlist<-list(ybar_c1q3,ybar_c1srs,y,ybar_c1q4,phi)
return(newlist)
} 
meany3<-mean(fq3(1)[[3]]) #y

aa<-seq(0,1,by=0.1)
e1q3<-e2q3<-c(0,times=length(aa))
g1q3<-g2q3<-c(0,times=length(aa))
for(k in 1:length(aa)){
e1q3[k]<-MSE(fq3(aa[k])[[2]],meany3)/MSE(fq3(aa[k])[[1]],meany3)
e2q3[k]<-MSE(fq3(aa[k])[[2]],meany3)/MSE(fq3(aa[k])[[4]],meany3)
g1q3[k]<-var(fq3(aa[k])[[1]])
g2q3[k]<-var(fq3(aa[k])[[4]])
}
opt1<-aa[which(g1q3==min(g1q3))]
opt2<-aa[which(g2q3==min(g2q3))]

t1<- seq(opt1-0.1, opt1+0.1,by=0.01)
t2<- seq(opt2-0.1, opt2+0.1,by=0.01)

v1<-v2<-c(0,times=length(t1))
for(k in 1:length(t1)){
v1[k]<-var(fq3(t1[k])[[1]])
}
alpha1q3<-t1[which(v1==min(v1))]

for(k in 1:length(t1)){
v2[k]<-var(fq3(t2[k])[[4]])
}
alpha2q3<-t2[which(v2==min(v2))]

bias1q3<-mean( fq3(alpha1q3)[[1]])-meany3
bias2q3<-mean( fq3(alpha2q3)[[4]])-meany3