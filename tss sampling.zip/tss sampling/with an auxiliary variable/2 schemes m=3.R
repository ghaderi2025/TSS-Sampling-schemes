#######################################################
#with an auxiliary variable scheme A_5 and A_6#
library(sn)               # generate trivariate normal
library(MLmetrics) # calculate MSE
N=1000
U<-1:N
l=5000
n=100
m=3
#####################################################
#ybarc2q5; ybar_c2 base on quantile with scheme A5 #
#ybarc2q6; ybar_c2 base on quantile with scheme A6 #
#ybarc2srs; ybar_c2 base under SRS scheme          #
ybarc2q5<-ybarc2srs<-ybarc2q6<-rep(0,times=l)
#####################################################
##Here, quantile starts from the first occasion##
# p1 is  place for selecting quantile in the first occasion for both schemes A_5 and A_6#
# pz1 is  place for selecting quantile in the matched portion A_5#
# dm1 is  place for selecting quantile in the matched portion A_6#
# d1 is  place for selecting quantile in the fresh sample in the both schemes A_5 and A_6 #
############ 2 scheme m=3  ##########
############   rho<-0.2    ######################################################
p1=seq(10,1000, length.out=n)
dm1=c(25,50,75)
pz1<-c(250,500,750)
nn<-n-m
mz1<-round(((1:nn)/(nn+1))*(N-n))
d1<-U[-p1][mz1]

# selection rho #
# we can use of this code for rho=0.2, 0.5, 0.8 and other values #
rho<-0.2    #rho xy
rho2<-0.2  # rhozy=rhozx

#####################################################
# create trivariate normal distribution in XYZ#
# x is study variable in the first occasion; y is study variable in the second occasion#
# z is the auxiliary variable in the both occasions#
# x1 is sample in the first occasion#
# x2 is the matched portion of the first sample under scheme A_5; y2 and z2  are the matched portion of the second sample under scheme  A_5 #
# tx2 is matched portion of the first sample under scheme A_6; yx2 and zx2  are matched portion of the second sample under scheme  A_6 #
# yu and zu are the frash sample under schemes  A_5 and A_6#
# xx1 is sample in the first occasion under scheme SRS#
# xx2 is the matched portion of the first sample under scheme SRS; yy2 and zz2  are the matched portion of the second sample under  scheme SRS#
# yy3 and zz3 are the frash sample  under scheme SRS#
#############

fq1<-function(alphaa){
for (i in 1:l){
sdd1<-64
sdd2<-100
sdd3<-25
sd1<-sqrt(sdd1)
sd2<-sqrt(sdd2)
sd3<-sqrt(sdd3)
sigma <- matrix(c(sdd1,rho*sd1*sd2, rho2*sd1*sd3,
                                     rho*sd1*sd2, sdd2, rho2*sd2*sd3, 
                                    rho2*sd1*sd3, rho2*sd2*sd3, sdd3), ncol = 3)
cp <- list(mean=c(100,120,40), var.cov=sigma, gamma1=c(0,0,0))
dp <- cp2dp(cp, "SN")
XYZ<- rmsn(N, dp=dp)
x<-XYZ[,1][order(XYZ[,3])]
y<-XYZ[,2][order(XYZ[,3])]
z<-XYZ[,3][order(XYZ[,3])]
xy<-c(x,y)
zc<-c(z,z)
rhonew<-cor(xy,zc)
zbarN<-mean(z)
x1<-x[p1]

x2<-x[pz1]
y2<-y[pz1]
z2<-z[pz1]
w1<-sum(x2^2)
w2<-sum(z2^2)
w3<-sum(x2*z2)
w4<-sum(x2*y2)
w5<-sum(z2*y2)
fb<-(w1*w2)-(w3)
b1<-((w2*w4)-(w3*w5))/fb
b2<-((w1*w5)-(w3*w4))/fb

xbarn<-mean(x1)
xbarm<-mean(x2)
ybarm<-mean(y2)
zbarm<-mean(z2)

t1<-sort(x1)
tx2<-t1[dm1]
zx2<-yx2<-c()
for(j in 1:m){
yx2[j]<-y[p1[x1==tx2[j]]]
zx2[j]<-z[p1[x1==tx2[j]]]
}
mtx<-mean(tx2)
zxm<-mean(zx2)
yxm<-mean(yx2)
wx1<-sum(tx2^2)
wx2<-sum(zx2^2)
wx3<-sum(tx2*zx2)
wx4<-sum(tx2*yx2)
wx5<-sum(zx2*yx2)
fxb<-(wx1*wx2)-(wx3)
bx1<-((wx2*wx4)-(wx3*wx5))/fxb
bx2<-((wx1*wx5)-(wx3*wx4))/fxb

zu<-z[d1]
yu<-y[d1]
yubar<-mean(yu)
zubar<-mean(zu)
beta2<-cov(yu,zu)/var(zu)

yRegz1<-yubar+beta2*(zbarN-zubar)                 #fresh
ybarReg2<-ybarm+b1*(xbarn-xbarm)+b2*(zbarN-zbarm) #matched qz
ybarRegx2<-yxm+bx1*(xbarn-mtx)+bx2*(zbarN-zxm)    #matched qx

ybarc2q5[i]<-alphaa*yRegz1+(1-alphaa)*ybarReg2
ybarc2q6[i]<-alphaa*yRegz1+(1-alphaa)*ybarRegx2

s1<-sample(U,size=n)
s12<-sample(s1,size=m)
s2<-sample(U[-s1],siz=n-m)
xx1<-x[s1]
zz1<-z[s1]
xx2<-x[s12]
zz2<-z[s12]
yy2<-y[s12]
yy3<-y[s2]
zz3<-z[s2]
zz4<-c(zz2,zz3)
yy4<-c(yy2,yy3)
h1<-sum(xx2^2)
h2<-sum(zz2^2)
h3<-sum(xx2*zz2)
h4<-sum(xx2*yy2)
h5<-sum(zz2*yy2)
mb<-h1*h2-h3
mb1<-((h2*h4)-(h3*h5))/mb
mb2<-((h1*h5)-(h3*h4))/mb
xxbarn<-mean(xx1)
yu<-mean(yy3)
zu<-mean(zz3)
xm<-mean(xx2)
ym<-mean(yy2)
zm<-mean(zz2)
bhatnewzy1<-cov(zz3,yy3)/var(zz3)
ybarRegznew1<-yu+bhatnewzy1*(zbarN-zu)
ybarRegznew2<-ym+mb1*(xxbarn-xm)+mb2*(zbarN-zm)
ybarc2srs[i]<-alphaa*ybarRegznew1+(1-alphaa)*(ybarRegznew2)
}
newlist<-list(ybarc2srs,ybarc2q5,ybarc2q6,y,rhonew)
return(newlist)
} 
#fq1(alphaa)[[1]] is ybarc2srs; fq1(alphaa)[[2]] is ybarc2q5;  fq1(alphaa)[[2]] is ybarc2q6#
#####################################################
meany<-mean(fq1(1)[[4]])           # mean(y) is not function of alpha
# e1q1; The relative efficiency of two estimators ybarc2srs and ybarc2q5 #
# e2q1; The relative efficiency of two estimators ybarc2srs and ybarc2q6 #
# Finding simulated alpha value with minimum variance under schemes A_5 and A_6#
# g1q1; variance(ybarc2q5) #
# g2q1; variance(ybarc2q6) #

meany<-mean(fq1(1)[[4]])#y
aa<-seq(0,1,by=0.1)
e1q1<-e2q1<-c(0,times=length(aa))
g1q1<-g2q1<-c(0,times=length(aa))
for(k in 1:length(aa)){
e1q1[k]<-MSE(fq1(aa[k])[[1]],meany)/MSE(fq1(aa[k])[[2]],meany)
e2q1[k]<-MSE(fq1(aa[k])[[1]],meany)/MSE(fq1(aa[k])[[3]],meany)
g1q1[k]<-var(fq1(aa[k])[[2]])
g2q1[k]<-var(fq1(aa[k])[[3]])
}

#Finding a more accurate value for the simulated  optimal alpha #
# alpha1q2 is simulated  optimal alpha under scheme A_5; alpha2q2 is simulated  optimal alpha under scheme A_6 #
opt1<-aa[which(g1q1==min(g1q1))]
opt2<-aa[which(g2q1==min(g2q1))]
t1<- seq(opt1-0.1, opt1+0.1,by=0.01)
t2<- seq(opt2-0.1, opt2+0.1,by=0.01)
v1<-v2<-c(0,times=length(t1))
for(k in 1:length(t1)){
v1[k]<-var(fq1(t1[k])[[2]])
}
alpha1q1<-t1[which(v1==min(v1))]

for(k in 1:length(t2)){
v2[k]<-var(fq1(t2[k])[[3]])
}
alpha2q1<-t2[which(v2==min(v2))]

#####################################################
# Relative bias percentage #
# bias1q1; RBP ybarc2q5 #
# bias2q1; RBP ybarc2q6 #
bias1q1<-(mean( fq1(alpha1q1)[[2]])-meany)*100/meany
bias2q1<-(mean( fq1(alpha2q1)[[3]])-meany)*100/meany

############  2           ##########################
rho2<-0.5
fq2<-function(alphaa){
for (i in 1:l){
set.seed(2*i)
sdd1<-64
sdd2<-100
sdd3<-25
sd1<-sqrt(sdd1)
sd2<-sqrt(sdd2)
sd3<-sqrt(sdd3)
sigma <- matrix(c(sdd1,rho*sd1*sd2, rho2*sd1*sd3,
                                     rho*sd1*sd2, sdd2, rho2*sd2*sd3, 
                                    rho2*sd1*sd3, rho2*sd2*sd3, sdd3), ncol = 3)
cp <- list(mean=c(100,120,40), var.cov=sigma, gamma1=c(0,0,0))
dp <- cp2dp(cp, "SN")
XYZ<- rmsn(N, dp=dp)
x<-XYZ[,1][order(XYZ[,3])]
y<-XYZ[,2][order(XYZ[,3])]
z<-XYZ[,3][order(XYZ[,3])]
xy<-c(x,y)
zc<-c(z,z)
rhonew<-cor(xy,zc)
zbarN<-mean(z)
x1<-x[p1]

x2<-x[pz1]
y2<-y[pz1]
z2<-z[pz1]
w1<-sum(x2^2)
w2<-sum(z2^2)
w3<-sum(x2*z2)
w4<-sum(x2*y2)
w5<-sum(z2*y2)
fb<-(w1*w2)-(w3)
b1<-((w2*w4)-(w3*w5))/fb
b2<-((w1*w5)-(w3*w4))/fb

xbarn<-mean(x1)
xbarm<-mean(x2)
ybarm<-mean(y2)
zbarm<-mean(z2)

t1<-sort(x1)
tx2<-t1[dm1]
zx2<-yx2<-c()
for(j in 1:m){
yx2[j]<-y[p1[x1==tx2[j]]]
zx2[j]<-z[p1[x1==tx2[j]]]
}
mtx<-mean(tx2)
zxm<-mean(zx2)
yxm<-mean(yx2)
wx1<-sum(tx2^2)
wx2<-sum(zx2^2)
wx3<-sum(tx2*zx2)
wx4<-sum(tx2*yx2)
wx5<-sum(zx2*yx2)
fxb<-(wx1*wx2)-(wx3)
bx1<-((wx2*wx4)-(wx3*wx5))/fxb
bx2<-((wx1*wx5)-(wx3*wx4))/fxb

zu<-z[d1]
yu<-y[d1]
yubar<-mean(yu)
zubar<-mean(zu)
beta2<-cov(yu,zu)/var(zu)

yRegz1<-yubar+beta2*(zbarN-zubar)                 #fresh
ybarReg2<-ybarm+b1*(xbarn-xbarm)+b2*(zbarN-zbarm) #matched qz
ybarRegx2<-yxm+bx1*(xbarn-mtx)+bx2*(zbarN-zxm)    #matched qx

ybarc2q5[i]<-alphaa*yRegz1+(1-alphaa)*ybarReg2
ybarc2q6[i]<-alphaa*yRegz1+(1-alphaa)*ybarRegx2

s1<-sample(U,size=n)
s12<-sample(s1,size=m)
s2<-sample(U[-s1],siz=n-m)
xx1<-x[s1]
zz1<-z[s1]
xx2<-x[s12]
zz2<-z[s12]
yy2<-y[s12]
yy3<-y[s2]
zz3<-z[s2]
zz4<-c(zz2,zz3)
yy4<-c(yy2,yy3)
h1<-sum(xx2^2)
h2<-sum(zz2^2)
h3<-sum(xx2*zz2)
h4<-sum(xx2*yy2)
h5<-sum(zz2*yy2)
mb<-h1*h2-h3
mb1<-((h2*h4)-(h3*h5))/mb
mb2<-((h1*h5)-(h3*h4))/mb
xxbarn<-mean(xx1)
yu<-mean(yy3)
zu<-mean(zz3)
xm<-mean(xx2)
ym<-mean(yy2)
zm<-mean(zz2)
bhatnewzy1<-cov(zz3,yy3)/var(zz3)
ybarRegznew1<-yu+bhatnewzy1*(zbarN-zu)
ybarRegznew2<-ym+mb1*(xxbarn-xm)+mb2*(zbarN-zm)
ybarc2srs[i]<-alphaa*ybarRegznew1+(1-alphaa)*(ybarRegznew2)
}
newlist<-list(ybarc2srs,ybarc2q5,ybarc2q6,y,rhonew)
return(newlist)
} 
meany<-mean(fq2(1)[[4]])#y
aa<-seq(0,1,by=0.1)
e1q2<-e2q2<-c(0,times=length(aa))
g1q2<-g2q2<-c(0,times=length(aa))
for(k in 1:length(aa)){
e1q2[k]<-MSE(fq2(aa[k])[[1]],meany)/MSE(fq2(aa[k])[[2]],meany)
e2q2[k]<-MSE(fq2(aa[k])[[1]],meany)/MSE(fq2(aa[k])[[3]],meany)
g1q2[k]<-var(fq2(aa[k])[[2]])
g2q2[k]<-var(fq2(aa[k])[[3]])
}
opt1<-aa[which(g1q2==min(g1q2))]
opt2<-aa[which(g2q2==min(g2q2))]
t1<- seq(opt1-0.1, opt1+0.1,by=0.01)
t2<- seq(opt2-0.1, opt2+0.1,by=0.01)
v1<-v2<-c(0,times=length(t1))
for(k in 1:length(t1)){
v1[k]<-var(fq2(t1[k])[[2]])
}
alpha1q2<-t1[which(v1==min(v1))]

for(k in 1:length(t2)){
v2[k]<-var(fq2(t2[k])[[3]])
}
alpha2q2<-t2[which(v2==min(v2))]

bias1q2<-(mean( fq2(alpha1q2)[[2]])-meany)*100/meany
bias2q2<-(mean( fq2(alpha2q2)[[3]])-meany)*100/meany

###################  3     ##############################################

############   rho<-0.5    ######################################################
rho<-0.5  

rho2<-0.2
fq3<-function(alphaa){
for (i in 1:l){
set.seed(2*i)
sdd1<-64
sdd2<-100
sdd3<-25
sd1<-sqrt(sdd1)
sd2<-sqrt(sdd2)
sd3<-sqrt(sdd3)
sigma <- matrix(c(sdd1,rho*sd1*sd2, rho2*sd1*sd3,
                                     rho*sd1*sd2, sdd2, rho2*sd2*sd3, 
                                    rho2*sd1*sd3, rho2*sd2*sd3, sdd3), ncol = 3)
cp <- list(mean=c(100,120,40), var.cov=sigma, gamma1=c(0,0,0))
dp <- cp2dp(cp, "SN")
XYZ<- rmsn(N, dp=dp)
x<-XYZ[,1][order(XYZ[,3])]
y<-XYZ[,2][order(XYZ[,3])]
z<-XYZ[,3][order(XYZ[,3])]
xy<-c(x,y)
zc<-c(z,z)
rhonew<-cor(xy,zc)
zbarN<-mean(z)
x1<-x[p1]

x2<-x[pz1]
y2<-y[pz1]
z2<-z[pz1]
w1<-sum(x2^2)
w2<-sum(z2^2)
w3<-sum(x2*z2)
w4<-sum(x2*y2)
w5<-sum(z2*y2)
fb<-(w1*w2)-(w3)
b1<-((w2*w4)-(w3*w5))/fb
b2<-((w1*w5)-(w3*w4))/fb

xbarn<-mean(x1)
xbarm<-mean(x2)
ybarm<-mean(y2)
zbarm<-mean(z2)

t1<-sort(x1)
tx2<-t1[dm1]
zx2<-yx2<-c()
for(j in 1:m){
yx2[j]<-y[p1[x1==tx2[j]]]
zx2[j]<-z[p1[x1==tx2[j]]]
}
mtx<-mean(tx2)
zxm<-mean(zx2)
yxm<-mean(yx2)
wx1<-sum(tx2^2)
wx2<-sum(zx2^2)
wx3<-sum(tx2*zx2)
wx4<-sum(tx2*yx2)
wx5<-sum(zx2*yx2)
fxb<-(wx1*wx2)-(wx3)
bx1<-((wx2*wx4)-(wx3*wx5))/fxb
bx2<-((wx1*wx5)-(wx3*wx4))/fxb

zu<-z[d1]
yu<-y[d1]
yubar<-mean(yu)
zubar<-mean(zu)
beta2<-cov(yu,zu)/var(zu)

yRegz1<-yubar+beta2*(zbarN-zubar)                 #fresh
ybarReg2<-ybarm+b1*(xbarn-xbarm)+b2*(zbarN-zbarm) #matched qz
ybarRegx2<-yxm+bx1*(xbarn-mtx)+bx2*(zbarN-zxm)    #matched qx

ybarc2q5[i]<-alphaa*yRegz1+(1-alphaa)*ybarReg2
ybarc2q6[i]<-alphaa*yRegz1+(1-alphaa)*ybarRegx2

s1<-sample(U,size=n)
s12<-sample(s1,size=m)
s2<-sample(U[-s1],siz=n-m)
xx1<-x[s1]
zz1<-z[s1]
xx2<-x[s12]
zz2<-z[s12]
yy2<-y[s12]
yy3<-y[s2]
zz3<-z[s2]
zz4<-c(zz2,zz3)
yy4<-c(yy2,yy3)
h1<-sum(xx2^2)
h2<-sum(zz2^2)
h3<-sum(xx2*zz2)
h4<-sum(xx2*yy2)
h5<-sum(zz2*yy2)
mb<-h1*h2-h3
mb1<-((h2*h4)-(h3*h5))/mb
mb2<-((h1*h5)-(h3*h4))/mb
xxbarn<-mean(xx1)
yu<-mean(yy3)
zu<-mean(zz3)
xm<-mean(xx2)
ym<-mean(yy2)
zm<-mean(zz2)
bhatnewzy1<-cov(zz3,yy3)/var(zz3)
ybarRegznew1<-yu+bhatnewzy1*(zbarN-zu)
ybarRegznew2<-ym+mb1*(xxbarn-xm)+mb2*(zbarN-zm)
ybarc2srs[i]<-alphaa*ybarRegznew1+(1-alphaa)*(ybarRegznew2)
}
newlist<-list(ybarc2srs,ybarc2q5,ybarc2q6,y,rhonew)
return(newlist)
} 
meany<-mean(fq3(1)[[4]])#y
aa<-seq(0,1,by=0.1)
e1q3<-e2q3<-c(0,times=length(aa))
g1q3<-g2q3<-c(0,times=length(aa))
for(k in 1:length(aa)){
e1q3[k]<-MSE(fq3(aa[k])[[1]],meany)/MSE(fq3(aa[k])[[2]],meany)
e2q3[k]<-MSE(fq3(aa[k])[[1]],meany)/MSE(fq3(aa[k])[[3]],meany)
g1q3[k]<-var(fq3(aa[k])[[2]])
g2q3[k]<-var(fq3(aa[k])[[3]])
}
opt1<-aa[which(g1q3==min(g1q3))]
opt2<-aa[which(g2q3==min(g2q3))]
t1<- seq(opt1-0.1, opt1+0.1,by=0.01)
t2<- seq(opt2-0.1, opt2+0.1,by=0.01)
v1<-v2<-c(0,times=length(t1))
for(k in 1:length(t1)){
v1[k]<-var(fq3(t1[k])[[2]])
}
alpha1q3<-t1[which(v1==min(v1))]

for(k in 1:length(t2)){
v2[k]<-var(fq3(t2[k])[[3]])
}
alpha2q3<-t2[which(v2==min(v2))]

bias1q3<-(mean( fq3(alpha1q3)[[2]])-meany)*100/meany
bias2q3<-(mean( fq3(alpha2q3)[[3]])-meany)*100/meany

####################  4  ############################################

rho2<-0.5
fq4<-function(alphaa){
for (i in 1:l){
set.seed(2*i)
sdd1<-64
sdd2<-100
sdd3<-25
sd1<-sqrt(sdd1)
sd2<-sqrt(sdd2)
sd3<-sqrt(sdd3)
sigma <- matrix(c(sdd1,rho*sd1*sd2, rho2*sd1*sd3,
                                     rho*sd1*sd2, sdd2, rho2*sd2*sd3, 
                                    rho2*sd1*sd3, rho2*sd2*sd3, sdd3), ncol = 3)
cp <- list(mean=c(100,120,40), var.cov=sigma, gamma1=c(0,0,0))
dp <- cp2dp(cp, "SN")
XYZ<- rmsn(N, dp=dp)
x<-XYZ[,1][order(XYZ[,3])]
y<-XYZ[,2][order(XYZ[,3])]
z<-XYZ[,3][order(XYZ[,3])]
xy<-c(x,y)
zc<-c(z,z)
rhonew<-cor(xy,zc)
zbarN<-mean(z)
x1<-x[p1]

x2<-x[pz1]
y2<-y[pz1]
z2<-z[pz1]
w1<-sum(x2^2)
w2<-sum(z2^2)
w3<-sum(x2*z2)
w4<-sum(x2*y2)
w5<-sum(z2*y2)
fb<-(w1*w2)-(w3)
b1<-((w2*w4)-(w3*w5))/fb
b2<-((w1*w5)-(w3*w4))/fb

xbarn<-mean(x1)
xbarm<-mean(x2)
ybarm<-mean(y2)
zbarm<-mean(z2)

t1<-sort(x1)
tx2<-t1[dm1]
zx2<-yx2<-c()
for(j in 1:m){
yx2[j]<-y[p1[x1==tx2[j]]]
zx2[j]<-z[p1[x1==tx2[j]]]
}
mtx<-mean(tx2)
zxm<-mean(zx2)
yxm<-mean(yx2)
wx1<-sum(tx2^2)
wx2<-sum(zx2^2)
wx3<-sum(tx2*zx2)
wx4<-sum(tx2*yx2)
wx5<-sum(zx2*yx2)
fxb<-(wx1*wx2)-(wx3)
bx1<-((wx2*wx4)-(wx3*wx5))/fxb
bx2<-((wx1*wx5)-(wx3*wx4))/fxb

zu<-z[d1]
yu<-y[d1]
yubar<-mean(yu)
zubar<-mean(zu)
beta2<-cov(yu,zu)/var(zu)

yRegz1<-yubar+beta2*(zbarN-zubar)                 #fresh
ybarReg2<-ybarm+b1*(xbarn-xbarm)+b2*(zbarN-zbarm) #matched qz
ybarRegx2<-yxm+bx1*(xbarn-mtx)+bx2*(zbarN-zxm)    #matched qx

ybarc2q5[i]<-alphaa*yRegz1+(1-alphaa)*ybarReg2
ybarc2q6[i]<-alphaa*yRegz1+(1-alphaa)*ybarRegx2

s1<-sample(U,size=n)
s12<-sample(s1,size=m)
s2<-sample(U[-s1],siz=n-m)
xx1<-x[s1]
zz1<-z[s1]
xx2<-x[s12]
zz2<-z[s12]
yy2<-y[s12]
yy3<-y[s2]
zz3<-z[s2]
zz4<-c(zz2,zz3)
yy4<-c(yy2,yy3)
h1<-sum(xx2^2)
h2<-sum(zz2^2)
h3<-sum(xx2*zz2)
h4<-sum(xx2*yy2)
h5<-sum(zz2*yy2)
mb<-h1*h2-h3
mb1<-((h2*h4)-(h3*h5))/mb
mb2<-((h1*h5)-(h3*h4))/mb
xxbarn<-mean(xx1)
yu<-mean(yy3)
zu<-mean(zz3)
xm<-mean(xx2)
ym<-mean(yy2)
zm<-mean(zz2)
bhatnewzy1<-cov(zz3,yy3)/var(zz3)
ybarRegznew1<-yu+bhatnewzy1*(zbarN-zu)
ybarRegznew2<-ym+mb1*(xxbarn-xm)+mb2*(zbarN-zm)
ybarc2srs[i]<-alphaa*ybarRegznew1+(1-alphaa)*(ybarRegznew2)
}
newlist<-list(ybarc2srs,ybarc2q5,ybarc2q6,y,rhonew)
return(newlist)
} 
meany<-mean(fq4(1)[[4]])#y
aa<-seq(0,1,by=0.1)
e1q4<-e2q4<-c(0,times=length(aa))
g1q4<-g2q4<-c(0,times=length(aa))
for(k in 1:length(aa)){
e1q4[k]<-MSE(fq4(aa[k])[[1]],meany)/MSE(fq4(aa[k])[[2]],meany)
e2q4[k]<-MSE(fq4(aa[k])[[1]],meany)/MSE(fq4(aa[k])[[3]],meany)
g1q4[k]<-var(fq4(aa[k])[[2]])
g2q4[k]<-var(fq4(aa[k])[[3]])
}
opt1<-aa[which(g1q1==min(g1q1))]
opt2<-aa[which(g2q1==min(g2q1))]
t1<- seq(opt1-0.1, opt1+0.1,by=0.01)
t2<- seq(opt2-0.1, opt2+0.1,by=0.01)
v1<-v2<-c(0,times=length(t1))
for(k in 1:length(t1)){
v1[k]<-var(fq4(t1[k])[[2]])
}
alpha1q4<-t1[which(v1==min(v1))]

for(k in 1:length(t2)){
v2[k]<-var(fq4(t2[k])[[3]])
}
alpha2q4<-t2[which(v2==min(v2))]

bias1q4<-(mean( fq4(alpha1q4)[[2]])-meany)*100/meany
bias2q4<-(mean( fq4(alpha2q4)[[3]])-meany)*100/meany

##########################  5  ############################

rho2<-0.8
fq5<-function(alphaa){
for (i in 1:l){
set.seed(2*i)
sdd1<-64
sdd2<-100
sdd3<-25
sd1<-sqrt(sdd1)
sd2<-sqrt(sdd2)
sd3<-sqrt(sdd3)
sigma <- matrix(c(sdd1,rho*sd1*sd2, rho2*sd1*sd3,
                                     rho*sd1*sd2, sdd2, rho2*sd2*sd3, 
                                    rho2*sd1*sd3, rho2*sd2*sd3, sdd3), ncol = 3)
cp <- list(mean=c(100,120,40), var.cov=sigma, gamma1=c(0,0,0))
dp <- cp2dp(cp, "SN")
XYZ<- rmsn(N, dp=dp)
x<-XYZ[,1][order(XYZ[,3])]
y<-XYZ[,2][order(XYZ[,3])]
z<-XYZ[,3][order(XYZ[,3])]
xy<-c(x,y)
zc<-c(z,z)
rhonew<-cor(xy,zc)
zbarN<-mean(z)
x1<-x[p1]

x2<-x[pz1]
y2<-y[pz1]
z2<-z[pz1]
w1<-sum(x2^2)
w2<-sum(z2^2)
w3<-sum(x2*z2)
w4<-sum(x2*y2)
w5<-sum(z2*y2)
fb<-(w1*w2)-(w3)
b1<-((w2*w4)-(w3*w5))/fb
b2<-((w1*w5)-(w3*w4))/fb

xbarn<-mean(x1)
xbarm<-mean(x2)
ybarm<-mean(y2)
zbarm<-mean(z2)

t1<-sort(x1)
tx2<-t1[dm1]
zx2<-yx2<-c()
for(j in 1:m){
yx2[j]<-y[p1[x1==tx2[j]]]
zx2[j]<-z[p1[x1==tx2[j]]]
}
mtx<-mean(tx2)
zxm<-mean(zx2)
yxm<-mean(yx2)
wx1<-sum(tx2^2)
wx2<-sum(zx2^2)
wx3<-sum(tx2*zx2)
wx4<-sum(tx2*yx2)
wx5<-sum(zx2*yx2)
fxb<-(wx1*wx2)-(wx3)
bx1<-((wx2*wx4)-(wx3*wx5))/fxb
bx2<-((wx1*wx5)-(wx3*wx4))/fxb

zu<-z[d1]
yu<-y[d1]
yubar<-mean(yu)
zubar<-mean(zu)
beta2<-cov(yu,zu)/var(zu)

yRegz1<-yubar+beta2*(zbarN-zubar)                 #fresh
ybarReg2<-ybarm+b1*(xbarn-xbarm)+b2*(zbarN-zbarm) #matched qz
ybarRegx2<-yxm+bx1*(xbarn-mtx)+bx2*(zbarN-zxm)    #matched qx

ybarc2q5[i]<-alphaa*yRegz1+(1-alphaa)*ybarReg2
ybarc2q6[i]<-alphaa*yRegz1+(1-alphaa)*ybarRegx2

s1<-sample(U,size=n)
s12<-sample(s1,size=m)
s2<-sample(U[-s1],siz=n-m)
xx1<-x[s1]
zz1<-z[s1]
xx2<-x[s12]
zz2<-z[s12]
yy2<-y[s12]
yy3<-y[s2]
zz3<-z[s2]
zz4<-c(zz2,zz3)
yy4<-c(yy2,yy3)
h1<-sum(xx2^2)
h2<-sum(zz2^2)
h3<-sum(xx2*zz2)
h4<-sum(xx2*yy2)
h5<-sum(zz2*yy2)
mb<-h1*h2-h3
mb1<-((h2*h4)-(h3*h5))/mb
mb2<-((h1*h5)-(h3*h4))/mb
xxbarn<-mean(xx1)
yu<-mean(yy3)
zu<-mean(zz3)
xm<-mean(xx2)
ym<-mean(yy2)
zm<-mean(zz2)
bhatnewzy1<-cov(zz3,yy3)/var(zz3)
ybarRegznew1<-yu+bhatnewzy1*(zbarN-zu)
ybarRegznew2<-ym+mb1*(xxbarn-xm)+mb2*(zbarN-zm)
ybarc2srs[i]<-alphaa*ybarRegznew1+(1-alphaa)*(ybarRegznew2)
}
newlist<-list(ybarc2srs,ybarc2q5,ybarc2q6,y,rhonew)
return(newlist)
} 
meany<-mean(fq5(1)[[4]])#y
aa<-seq(0,1,by=0.1)
e1q5<-e2q5<-c(0,times=length(aa))
g1q5<-g2q5<-c(0,times=length(aa))
for(k in 1:length(aa)){
e1q5[k]<-MSE(fq5(aa[k])[[1]],meany)/MSE(fq5(aa[k])[[2]],meany)
e2q5[k]<-MSE(fq5(aa[k])[[1]],meany)/MSE(fq5(aa[k])[[3]],meany)
g1q5[k]<-var(fq5(aa[k])[[2]])
g2q5[k]<-var(fq5(aa[k])[[3]])
}
opt1<-aa[which(g1q5==min(g1q5))]
opt2<-aa[which(g2q5==min(g2q5))]
t1<- seq(opt1-0.1, opt1+0.1,by=0.01)
t2<- seq(opt2-0.1, opt2+0.1,by=0.01)
v1<-v2<-c(0,times=length(t1))
for(k in 1:length(t1)){
v1[k]<-var(fq5(t1[k])[[2]])
}
alpha1q5<-t1[which(v1==min(v1))]

for(k in 1:length(t2)){
v2[k]<-var(fq5(t2[k])[[3]])
}
alpha2q5<-t2[which(v2==min(v2))]

bias1q5<-(mean( fq5(alpha1q5)[[2]])-meany)*100/meany
bias2q5<-(mean( fq5(alpha2q5)[[3]])-meany)*100/meany

############  6  ######################################

############   rho<-0.8   ######################################################

rho<-0.8  
############################
rho2<-0.2
fq6<-function(alphaa){
for (i in 1:l){
set.seed(2*i)
sdd1<-64
sdd2<-100
sdd3<-25
sd1<-sqrt(sdd1)
sd2<-sqrt(sdd2)
sd3<-sqrt(sdd3)
sigma <- matrix(c(sdd1,rho*sd1*sd2, rho2*sd1*sd3,
                                     rho*sd1*sd2, sdd2, rho2*sd2*sd3, 
                                    rho2*sd1*sd3, rho2*sd2*sd3, sdd3), ncol = 3)
cp <- list(mean=c(100,120,40), var.cov=sigma, gamma1=c(0,0,0))
dp <- cp2dp(cp, "SN")
XYZ<- rmsn(N, dp=dp)
x<-XYZ[,1][order(XYZ[,3])]
y<-XYZ[,2][order(XYZ[,3])]
z<-XYZ[,3][order(XYZ[,3])]
xy<-c(x,y)
zc<-c(z,z)
rhonew<-cor(xy,zc)
zbarN<-mean(z)
x1<-x[p1]

x2<-x[pz1]
y2<-y[pz1]
z2<-z[pz1]
w1<-sum(x2^2)
w2<-sum(z2^2)
w3<-sum(x2*z2)
w4<-sum(x2*y2)
w5<-sum(z2*y2)
fb<-(w1*w2)-(w3)
b1<-((w2*w4)-(w3*w5))/fb
b2<-((w1*w5)-(w3*w4))/fb

xbarn<-mean(x1)
xbarm<-mean(x2)
ybarm<-mean(y2)
zbarm<-mean(z2)

t1<-sort(x1)
tx2<-t1[dm1]
zx2<-yx2<-c()
for(j in 1:m){
yx2[j]<-y[p1[x1==tx2[j]]]
zx2[j]<-z[p1[x1==tx2[j]]]
}
mtx<-mean(tx2)
zxm<-mean(zx2)
yxm<-mean(yx2)
wx1<-sum(tx2^2)
wx2<-sum(zx2^2)
wx3<-sum(tx2*zx2)
wx4<-sum(tx2*yx2)
wx5<-sum(zx2*yx2)
fxb<-(wx1*wx2)-(wx3)
bx1<-((wx2*wx4)-(wx3*wx5))/fxb
bx2<-((wx1*wx5)-(wx3*wx4))/fxb

zu<-z[d1]
yu<-y[d1]
yubar<-mean(yu)
zubar<-mean(zu)
beta2<-cov(yu,zu)/var(zu)

yRegz1<-yubar+beta2*(zbarN-zubar)                 #fresh
ybarReg2<-ybarm+b1*(xbarn-xbarm)+b2*(zbarN-zbarm) #matched qz
ybarRegx2<-yxm+bx1*(xbarn-mtx)+bx2*(zbarN-zxm)    #matched qx

ybarc2q5[i]<-alphaa*yRegz1+(1-alphaa)*ybarReg2
ybarc2q6[i]<-alphaa*yRegz1+(1-alphaa)*ybarRegx2

s1<-sample(U,size=n)
s12<-sample(s1,size=m)
s2<-sample(U[-s1],siz=n-m)
xx1<-x[s1]
zz1<-z[s1]
xx2<-x[s12]
zz2<-z[s12]
yy2<-y[s12]
yy3<-y[s2]
zz3<-z[s2]
zz4<-c(zz2,zz3)
yy4<-c(yy2,yy3)
h1<-sum(xx2^2)
h2<-sum(zz2^2)
h3<-sum(xx2*zz2)
h4<-sum(xx2*yy2)
h5<-sum(zz2*yy2)
mb<-h1*h2-h3
mb1<-((h2*h4)-(h3*h5))/mb
mb2<-((h1*h5)-(h3*h4))/mb
xxbarn<-mean(xx1)
yu<-mean(yy3)
zu<-mean(zz3)
xm<-mean(xx2)
ym<-mean(yy2)
zm<-mean(zz2)
bhatnewzy1<-cov(zz3,yy3)/var(zz3)
ybarRegznew1<-yu+bhatnewzy1*(zbarN-zu)
ybarRegznew2<-ym+mb1*(xxbarn-xm)+mb2*(zbarN-zm)
ybarc2srs[i]<-alphaa*ybarRegznew1+(1-alphaa)*(ybarRegznew2)
}
newlist<-list(ybarc2srs,ybarc2q5,ybarc2q6,y,rhonew)
return(newlist)
} 
meany<-mean(fq6(1)[[4]])#y
aa<-seq(0,1,by=0.1)
e1q6<-e2q6<-c(0,times=length(aa))
g1q6<-g2q6<-c(0,times=length(aa))
for(k in 1:length(aa)){
e1q6[k]<-MSE(fq6(aa[k])[[1]],meany)/MSE(fq6(aa[k])[[2]],meany)
e2q6[k]<-MSE(fq6(aa[k])[[1]],meany)/MSE(fq6(aa[k])[[3]],meany)
g1q6[k]<-var(fq6(aa[k])[[2]])
g2q6[k]<-var(fq6(aa[k])[[3]])
}
opt1<-aa[which(g1q6==min(g1q6))]
opt2<-aa[which(g2q6==min(g2q6))]
t1<- seq(opt1-0.1, opt1+0.1,by=0.01)
t2<- seq(opt2-0.1, opt2+0.1,by=0.01)
v1<-v2<-c(0,times=length(t1))
for(k in 1:length(t1)){
v1[k]<-var(fq6(t1[k])[[2]])
}
alpha1q6<-t1[which(v1==min(v1))]

for(k in 1:length(t2)){
v2[k]<-var(fq6(t2[k])[[3]])
}
alpha2q6<-t2[which(v2==min(v2))]

bias1q6<-(mean( fq6(alpha1q6)[[2]])-meany)*100/meany
bias2q6<-(mean( fq6(alpha2q6)[[3]])-meany)*100/meany

###################   7  #####################################

rho2<-0.5
fq7<-function(alphaa){
for (i in 1:l){
set.seed(2*i)
sdd1<-64
sdd2<-100
sdd3<-25
sd1<-sqrt(sdd1)
sd2<-sqrt(sdd2)
sd3<-sqrt(sdd3)
sigma <- matrix(c(sdd1,rho*sd1*sd2, rho2*sd1*sd3,
                                     rho*sd1*sd2, sdd2, rho2*sd2*sd3, 
                                    rho2*sd1*sd3, rho2*sd2*sd3, sdd3), ncol = 3)
cp <- list(mean=c(100,120,40), var.cov=sigma, gamma1=c(0,0,0))
dp <- cp2dp(cp, "SN")
XYZ<- rmsn(N, dp=dp)
x<-XYZ[,1][order(XYZ[,3])]
y<-XYZ[,2][order(XYZ[,3])]
z<-XYZ[,3][order(XYZ[,3])]
xy<-c(x,y)
zc<-c(z,z)
rhonew<-cor(xy,zc)
zbarN<-mean(z)
x1<-x[p1]

x2<-x[pz1]
y2<-y[pz1]
z2<-z[pz1]
w1<-sum(x2^2)
w2<-sum(z2^2)
w3<-sum(x2*z2)
w4<-sum(x2*y2)
w5<-sum(z2*y2)
fb<-(w1*w2)-(w3)
b1<-((w2*w4)-(w3*w5))/fb
b2<-((w1*w5)-(w3*w4))/fb

xbarn<-mean(x1)
xbarm<-mean(x2)
ybarm<-mean(y2)
zbarm<-mean(z2)

t1<-sort(x1)
tx2<-t1[dm1]
zx2<-yx2<-c()
for(j in 1:m){
yx2[j]<-y[p1[x1==tx2[j]]]
zx2[j]<-z[p1[x1==tx2[j]]]
}
mtx<-mean(tx2)
zxm<-mean(zx2)
yxm<-mean(yx2)
wx1<-sum(tx2^2)
wx2<-sum(zx2^2)
wx3<-sum(tx2*zx2)
wx4<-sum(tx2*yx2)
wx5<-sum(zx2*yx2)
fxb<-(wx1*wx2)-(wx3)
bx1<-((wx2*wx4)-(wx3*wx5))/fxb
bx2<-((wx1*wx5)-(wx3*wx4))/fxb

zu<-z[d1]
yu<-y[d1]
yubar<-mean(yu)
zubar<-mean(zu)
beta2<-cov(yu,zu)/var(zu)

yRegz1<-yubar+beta2*(zbarN-zubar)                 #fresh
ybarReg2<-ybarm+b1*(xbarn-xbarm)+b2*(zbarN-zbarm) #matched qz
ybarRegx2<-yxm+bx1*(xbarn-mtx)+bx2*(zbarN-zxm)    #matched qx

ybarc2q5[i]<-alphaa*yRegz1+(1-alphaa)*ybarReg2
ybarc2q6[i]<-alphaa*yRegz1+(1-alphaa)*ybarRegx2

s1<-sample(U,size=n)
s12<-sample(s1,size=m)
s2<-sample(U[-s1],siz=n-m)
xx1<-x[s1]
zz1<-z[s1]
xx2<-x[s12]
zz2<-z[s12]
yy2<-y[s12]
yy3<-y[s2]
zz3<-z[s2]

zz4<-c(zz2,zz3)
yy4<-c(yy2,yy3)

h1<-sum(xx2^2)
h2<-sum(zz2^2)
h3<-sum(xx2*zz2)
h4<-sum(xx2*yy2)
h5<-sum(zz2*yy2)
mb<-h1*h2-h3
mb1<-((h2*h4)-(h3*h5))/mb
mb2<-((h1*h5)-(h3*h4))/mb
xxbarn<-mean(xx1)
yu<-mean(yy3)
zu<-mean(zz3)
xm<-mean(xx2)
ym<-mean(yy2)
zm<-mean(zz2)
bhatnewzy1<-cov(zz3,yy3)/var(zz3)
ybarRegznew1<-yu+bhatnewzy1*(zbarN-zu)
ybarRegznew2<-ym+mb1*(xxbarn-xm)+mb2*(zbarN-zm)
ybarc2srs[i]<-alphaa*ybarRegznew1+(1-alphaa)*(ybarRegznew2)
}
newlist<-list(ybarc2srs,ybarc2q5,ybarc2q6,y,rhonew)
return(newlist)
} 
meany<-mean(fq7(1)[[4]])#y
aa<-seq(0,1,by=0.1)
e1q7<-e2q7<-c(0,times=length(aa))
g1q7<-g2q7<-c(0,times=length(aa))
for(k in 1:length(aa)){
e1q7[k]<-MSE(fq7(aa[k])[[1]],meany)/MSE(fq7(aa[k])[[2]],meany)
e2q7[k]<-MSE(fq7(aa[k])[[1]],meany)/MSE(fq7(aa[k])[[3]],meany)
g1q7[k]<-var(fq7(aa[k])[[2]])
g2q7[k]<-var(fq7(aa[k])[[3]])
}
opt1<-aa[which(g1q7==min(g1q7))]
opt2<-aa[which(g2q7==min(g2q7))]
t1<- seq(opt1-0.1, opt1+0.1,by=0.01)
t2<- seq(opt2-0.1, opt2+0.1,by=0.01)
v1<-v2<-c(0,times=length(t1))
for(k in 1:length(t1)){
v1[k]<-var(fq7(t1[k])[[2]])
}
alpha1q7<-t1[which(v1==min(v1))]

for(k in 1:length(t2)){
v2[k]<-var(fq7(t2[k])[[3]])
}
alpha2q7<-t2[which(v2==min(v2))]

bias1q7<-(mean( fq7(alpha1q7)[[2]])-meany)*100/meany
bias2q7<-(mean( fq7(alpha2q7)[[3]])-meany)*100/meany

################  8 #################################################

rho2<-0.8
fq8<-function(alphaa){
for (i in 1:l){
set.seed(2*i)
sdd1<-64
sdd2<-100
sdd3<-25
sd1<-sqrt(sdd1)
sd2<-sqrt(sdd2)
sd3<-sqrt(sdd3)
sigma <- matrix(c(sdd1,rho*sd1*sd2, rho2*sd1*sd3,
                                     rho*sd1*sd2, sdd2, rho2*sd2*sd3, 
                                    rho2*sd1*sd3, rho2*sd2*sd3, sdd3), ncol = 3)
cp <- list(mean=c(100,120,40), var.cov=sigma, gamma1=c(0,0,0))
dp <- cp2dp(cp, "SN")
XYZ<- rmsn(N, dp=dp)
x<-XYZ[,1][order(XYZ[,3])]
y<-XYZ[,2][order(XYZ[,3])]
z<-XYZ[,3][order(XYZ[,3])]
xy<-c(x,y)
zc<-c(z,z)
rhonew<-cor(xy,zc)
zbarN<-mean(z)
x1<-x[p1]

x2<-x[pz1]
y2<-y[pz1]
z2<-z[pz1]
w1<-sum(x2^2)
w2<-sum(z2^2)
w3<-sum(x2*z2)
w4<-sum(x2*y2)
w5<-sum(z2*y2)
fb<-(w1*w2)-(w3)
b1<-((w2*w4)-(w3*w5))/fb
b2<-((w1*w5)-(w3*w4))/fb

xbarn<-mean(x1)
xbarm<-mean(x2)
ybarm<-mean(y2)
zbarm<-mean(z2)

t1<-sort(x1)
tx2<-t1[dm1]
zx2<-yx2<-c()
for(j in 1:m){
yx2[j]<-y[p1[x1==tx2[j]]]
zx2[j]<-z[p1[x1==tx2[j]]]
}
mtx<-mean(tx2)
zxm<-mean(zx2)
yxm<-mean(yx2)
wx1<-sum(tx2^2)
wx2<-sum(zx2^2)
wx3<-sum(tx2*zx2)
wx4<-sum(tx2*yx2)
wx5<-sum(zx2*yx2)
fxb<-(wx1*wx2)-(wx3)
bx1<-((wx2*wx4)-(wx3*wx5))/fxb
bx2<-((wx1*wx5)-(wx3*wx4))/fxb

zu<-z[d1]
yu<-y[d1]
yubar<-mean(yu)
zubar<-mean(zu)
beta2<-cov(yu,zu)/var(zu)

yRegz1<-yubar+beta2*(zbarN-zubar)                 #fresh
ybarReg2<-ybarm+b1*(xbarn-xbarm)+b2*(zbarN-zbarm) #matched qz
ybarRegx2<-yxm+bx1*(xbarn-mtx)+bx2*(zbarN-zxm)    #matched qx

ybarc2q5[i]<-alphaa*yRegz1+(1-alphaa)*ybarReg2
ybarc2q6[i]<-alphaa*yRegz1+(1-alphaa)*ybarRegx2

s1<-sample(U,size=n)
s12<-sample(s1,size=m)
s2<-sample(U[-s1],siz=n-m)
xx1<-x[s1]
zz1<-z[s1]
xx2<-x[s12]
zz2<-z[s12]
yy2<-y[s12]
yy3<-y[s2]
zz3<-z[s2]
zz4<-c(zz2,zz3)
yy4<-c(yy2,yy3)
h1<-sum(xx2^2)
h2<-sum(zz2^2)
h3<-sum(xx2*zz2)
h4<-sum(xx2*yy2)
h5<-sum(zz2*yy2)
mb<-h1*h2-h3
mb1<-((h2*h4)-(h3*h5))/mb
mb2<-((h1*h5)-(h3*h4))/mb
xxbarn<-mean(xx1)
yu<-mean(yy3)
zu<-mean(zz3)
xm<-mean(xx2)
ym<-mean(yy2)
zm<-mean(zz2)
bhatnewzy1<-cov(zz3,yy3)/var(zz3)
ybarRegznew1<-yu+bhatnewzy1*(zbarN-zu)
ybarRegznew2<-ym+mb1*(xxbarn-xm)+mb2*(zbarN-zm)
ybarc2srs[i]<-alphaa*ybarRegznew1+(1-alphaa)*(ybarRegznew2)
}
newlist<-list(ybarc2srs,ybarc2q5,ybarc2q6,y,rhonew)
return(newlist)
} 
meany<-mean(fq8(1)[[4]])#y
aa<-seq(0,1,by=0.1)
e1q8<-e2q8<-c(0,times=length(aa))
g1q8<-g2q8<-c(0,times=length(aa))
for(k in 1:length(aa)){
e1q8[k]<-MSE(fq8(aa[k])[[1]],meany)/MSE(fq8(aa[k])[[2]],meany)
e2q8[k]<-MSE(fq8(aa[k])[[1]],meany)/MSE(fq8(aa[k])[[3]],meany)
g1q8[k]<-var(fq8(aa[k])[[2]])
g2q8[k]<-var(fq8(aa[k])[[3]])
}
opt1<-aa[which(g1q1==min(g1q1))]
opt2<-aa[which(g2q1==min(g2q1))]
t1<- seq(opt1-0.1, opt1+0.1,by=0.01)
t2<- seq(opt2-0.1, opt2+0.1,by=0.01)
v1<-v2<-c(0,times=length(t1))
for(k in 1:length(t1)){
v1[k]<-var(fq8(t1[k])[[2]])
}
alpha1q8<-t1[which(v1==min(v1))]

for(k in 1:length(t2)){
v2[k]<-var(fq8(t2[k])[[3]])
}
alpha2q8<-t2[which(v2==min(v2))]

bias1q8<-(mean( fq8(alpha1q8)[[2]])-meany)*100/meany
bias2q8<-(mean( fq8(alpha2q8)[[3]])-meany)*100/meany

################################################################################
maxq<-max(c(e1q1,e2q1,e1q2,e2q2,e1q3,e2q3,e1q4,e2q4,e1q5,e2q5,e1q6,e2q6,e1q7,e2q7,e1q8,e2q8))
minq<-min(c(e1q1,e2q1,e1q2,e2q2,e1q3,e2q3,e1q4,e2q4,e1q5,e2q5,e1q6,e2q6,e1q7,e2q7,e1q8,e2q8))

################  plot  ####################################
par(mfrow=c(3,3))
library(latex2exp)
library(berryFunctions)

qminq=0.8
qmq=2.9
aa<-seq(0,1,by=0.1)

plot(aa,e1q1,type = "l",lwd=2, pch = 19,col='blue',main=TeX(r'($\rho_{xy}$=0.2,$rho_{zy}$=0.2)'),xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#par(new=T)
lines(aa,e2q1,type='l',pch = 18,lty=2,lwd=2,col='red',xlab="alpha",ylab="efficiency",ylim=c(qminq,qmq))

plot(aa,e1q2,type='l',lwd=2, pch = 19,col='blue',main=TeX(r'($\rho_{xy}$=0.2,$rho_{zy}$=0.5)'),xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#par(new=T)
lines(aa,e2q2,type='l',pch = 18,lty=2,lwd=2,col='red',xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))

plot(0, xaxt = 'n', yaxt = 'n', bty = 'n', pch = '', ylab = '', xlab = '')
text(x = 0.9,y = 0.5,"Doesn't exists")

plot(aa,e1q4,type='l',lwd=2,pch = 19,col='blue',main=TeX(r'($\rho_{xy}$=0.5,$rho_{zy}$=0.2)'),xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#par(new=T)
lines(aa,e2q4,type='l',pch = 18,lty=2,lwd=2,col='red',xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))

plot(aa,e1q4,type='l',lwd=2,pch = 19,col='blue',main=TeX(r'($\rho_{xy}$=0.5,$rho_{zy}$=0.5)'),xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#par(new=T)
lines(aa,e2q4,type='l',pch = 18,lty=2,lwd=2,col='red',xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))

plot(aa,e1q5,type='l',lwd=2,pch = 19,col='blue',main=TeX(r'($\rho_{xy}$=0.5,$rho_{zy}$=0.8)'),xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#par(new=T)
lines(aa,e2q5,type='l',pch = 18,lty=2,lwd=2,col='red',xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#
plot(aa,e1q6,type='l',lwd=2,pch = 19,col='blue',main=TeX(r'($\rho_{xy}$=0.8,$rho_{zy}$=0.2)'),xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#par(new=T)
lines(aa,e2q6,type='l',pch = 18,lty=2,lwd=2,col='red',xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))

plot(aa,e1q7,type='l',lwd=2,pch = 19,col='blue',main=TeX(r'($\rho_{xy}$=0.8,$rho_{zy}$=0.5)'),xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#par(new=T)
lines(aa,e2q7,type='l',pch = 18,lty=2,lwd=2,col='red',xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))

plot(aa,e1q8,type='l',lwd=2,pch = 19,col='blue',main=TeX(r'($\rho_{xy}$=0.8,$rho_{zy}$=0.8)'),xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#par(new=T)
lines(aa,e2q8,type='l',pch = 18,lty=2,lwd=2,col='red',xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))

plot(aa,e1q4,type='l',lwd=2,pch = 19,col='blue',main=TeX(r'($\rho_{xy}$=0.5,$rho_{zy}$=0.2)'),xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#par(new=T)
lines(aa,e2q4,type='l',pch = 18,lty=2,lwd=2,col='red',xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))

plot(aa,e1q4,type='l',lwd=2,pch = 19,col='blue',main=TeX(r'($\rho_{xy}$=0.5,$rho_{zy}$=0.5)'),xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#par(new=T)
lines(aa,e2q4,type='l',pch = 18,lty=2,lwd=2,col='red',xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))

plot(aa,e1q5,type='l',lwd=2,pch = 19,col='blue',main=TeX(r'($\rho_{xy}$=0.5,$rho_{zy}$=0.8)'),xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#par(new=T)
lines(aa,e2q5,type='l',pch = 18,lty=2,lwd=2,col='red',xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#
plot(aa,e1q6,type='l',lwd=2,pch = 19,col='blue',main=TeX(r'($\rho_{xy}$=0.8,$rho_{zy}$=0.2)'),xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#par(new=T)
lines(aa,e2q6,type='l',pch = 18,lty=2,lwd=2,col='red',xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))

plot(aa,e1q7,type='l',lwd=2,pch = 19,col='blue',main=TeX(r'($\rho_{xy}$=0.8,$rho_{zy}$=0.5)'),xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#par(new=T)
lines(aa,e2q7,type='l',pch = 18,lty=2,lwd=2,col='red',xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))

plot(aa,e1q8,type='l',lwd=2,pch = 19,col='blue',main=TeX(r'($\rho_{xy}$=0.8,$rho_{zy}$=0.8)'),xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))
#par(new=T)
lines(aa,e2q8,type='l',pch = 18,lty=2,lwd=2,col='red',xlab=TeX(r'($\alpha$)'),ylab="efficiency",ylim=c(qminq,qmq))




